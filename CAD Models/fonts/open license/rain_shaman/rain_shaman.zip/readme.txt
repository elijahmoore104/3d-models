This font is 100% free for personal and commercial use.
No need to ask to use.
No worries, it's really free. 