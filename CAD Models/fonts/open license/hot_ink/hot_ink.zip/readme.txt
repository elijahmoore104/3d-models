This font is for personal and commercial license allowed!
My shop please visit: 
https://bit.ly/3vqNMW4